# AutoPilot Architecture

## Module map

```
autopilot/
  main.py                     CLI entry; DI container; hotkey callbacks; F2 sampling UI
  run_gui.py                  GUI entry; passes window_config into DI
  gui_launcher.py             Tk GUI; "sample template" button -> _region_select
  application/
    bot_engine.py             state machine driver; engine loop; start/stop/lock discipline
    strategies/
      base_strategy.py        foreground window bring-up, shared helpers
      gather_strategy.py      the 877-line core: scan/move/verify/vision-fallback/AI-train
  core/                       StateMachine, EventBus, DI container
  domain/                     pydantic models, enums (BotMode, RecoveryStrategy, ...)
  infrastructure/
    template_store.py         TemplateStore: LRU + gray cache + pyramid + matchTemplate
    screen_grabber.py         mss wrapper: grab() / grab_roi()
    vision_client.py          DeepSeek vision fallback; LOCATE/DESCRIBE prompts
    vision_channel.py         VisionTargetChannel: thread-safe push/consume (TTL)
    config_watcher.py         watchdog + debounce + pydantic validation + hot reload
    input_simulator.py        bezier move, lognormal click, sticky anti-duplicate
  docs/                       historical delivery docs (noisy, not authoritative)
```

## Match pipeline (gather tick)

```
_scan_for_resources():
  grab()                        full-screen BGR numpy
  _windowed_view(screenshot)    numpy slice to game window + origin offset
  _template_pool()              [active] + [rot_* copies] + [recent ai_*]   (self-learning)
  find_multiple_matches(crop, pool, scales=[1.0], threshold=0.70, nms=0.3)
  -> candidates sorted by confidence
  skip _is_recent_target(loc)   sticky anti-duplicate (recent_targets TTL)
  pick first un-blacklisted -> MOVING
```

- **Frame tracking**: if `_last_hit` within `track_ttl` (6 s), search only
  +/-`track_radius` (150 px) around it (~23x smaller area); else global. Expired
  -> fall back to global and clear memory. Proven view sequence:
  global -> local -> expired-global.
- **Self-learning pool**: `_template_pool()` = active template + its `rot_*`
  rotation copies + latest `pool_max_ai` (3) `ai_*` templates. `_match_pool()`
  merges all candidates by confidence desc; one bad template only warns + skips.
- **Vision fallback**: OpenCV miss >= 8 -> `VisionTargetChannel.consume()` first
  (zero quota if a manual hit exists), else `_vision_locate()` throttled
  (`miss_count % miss_trigger == 0`). Saves 64x64 `ai_*` crop on hit.

## Config schema (config.ini)

```
[DEFAULT]
threshold = 0.70             match confidence floor
scales = [1.0]               gather targets are constant size; list all steps if widened
recovery_strategy = ROTATE
match_method = TM_CCOEFF_NORMED    or TM_SQDIFF_NORMED (lower-is-better, auto-detected)

[strategy.gather]            overrides DEFAULT for gather only
template_id = (sampled stem)
rotation_step = 15          0 = off; 15-degree planar-rotation augmentation
track_enabled = true
track_radius = 150
track_ttl = 6
pool_max_ai = 3

[window]
window_title = (REAL game window title)    NOT the game.exe placeholder
```

### `_densify_scales` behavior (subtle)
Given configured `scales`, it interpolates steps of `0.05` between min and max
**only if** `max - min <= 1.0`. Beyond that it returns the config unchanged.
To widen range past 1.0 you must list every step explicitly.

## Coordinate systems
- `screen_grabber.grab()` / `grab_roi()` -> physical pixels (mss), same space as
  numpy array indices. No DPI scaling.
- Windowed view: `crop, origin = _windowed_view(shot)`; match coords are relative
  to `crop`; absolute = `origin + loc + window_offset`. Vision fallback coords
  get `scale_back` then `+ origin` to map to the same absolute space.
