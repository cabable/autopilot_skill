# Roadmap & Open Issues

## Known issues (from code review, status noted)
- **config.ini regex-replace** (`update_gather_template_id` / `set_config_value`):
  fragile -- if the format changes, `count==0` and it silently skips. Better: a
  comment-preserving config writer, or move runtime state (current template_id)
  to a separate file. *Not yet redesigned.*
- **`gather_strategy.py` ~877 lines**: scan/move/verify/vision/AI-train in one
  class. Candidate split: `_scan_for_resources` / `_verify_gathering` /
  `_vision_locate` into submodules. *Big refactor, needs tests -- deferred.*
- **Async EventBus** (`publish_async` / `_async_delivery_loop`): unused complexity;
  either adopt or delete. GIL makes the lock-semantics inconsistency benign but
  unclear.
- **`_perlin_noise`**: actually `sin` superposition, not Perlin -- rename to
  `jitter` or implement real Perlin. Documentation currently misleading.
- **`_verify_ocv.py`**: hardcodes `E:\scripts\...` paths + reads private members
  (`store._match_method`). Verification-only; acceptable but not portable.
- **`requirements.txt`**: pin versions (pydantic / watchdog / mss / mouse /
  keyboard / opencv / numpy) before distribution to avoid breaking upgrades.

## Concurrency -- already fixed (keep discipline)
- `stop()` no longer joins under lock; `ConfigWatcher` callback runs outside its
  lock. See lessons #7.

## Full-automation gap analysis
Current state is about 80% of single-scene unattended gather. To reach "truly
hands-off":
- **Short term (about 2-4 work days)**: handle "all targets consumed" (rotate/
  return/switch point); auto-recover from stuck / attacked / pathing-fail.
- **Mid term (about 2-4 weeks)**: multi-mode unattended (gather+combat+fishing),
  inventory-full -> town, reconnect, stamina handling. Reaches "can leave it
  running but glance occasionally".
- **Long term**: no real finish line -- game updates / map changes require ongoing
  maintenance. Rotation augmentation + AI fallback already cover most
  angle/occlusion cases for constant-size planar targets.

## What was intentionally NOT included in this skill
The `E:\scripts\docs\autopilot\docs\` set contains about 15 repetitive
`PROJECT_*/FINAL_*/DELIVERY_*` files with heavily overlapping content. They are
maintenance noise; the authoritative knowledge (architecture, lessons, workflows,
roadmap) is captured here. Keep `README.md`, `FIX_SUMMARY.md`,
`AUTOPILOT_REVIEW.md`, `AUTOPILOT_FIXES.md`, `OPTIMIZATION_REPORT.md`, and
`E:\scripts\overview.md` as the source-of-truth docs; prune the boilerplate when
convenient.
