# Workflows

## A. Sample a template (F2 / GUI "sample template" button)
1. Press **F2** (or click the button). A frozen full-screen snapshot pops up.
2. Left-drag a box tightly around the **target only** (40-120 px; cap 150 px).
   Release to confirm; right-click / Esc / 60 s timeout cancels.
3. The crop is sliced from **that same frame** and saved to
   `autopilot/templates/template_TIMESTAMP.png`. `rotation_step` copies are
   generated automatically (`rot_STEM_ANGLE.png`); old templates have none, so
   **re-sample once** after enabling rotation.
4. `config.ini` `[strategy.gather] template_id` is auto-written (hot reload).
5. Press **F5** to gather. Look for log fields `mode=track/global` and `pool=N`
   to confirm tracking + pool are active.

## B. Tune matching (hot-reload; no restart)
Edit `[strategy.gather]` (NOT `[DEFAULT]`, to avoid affecting combat/fishing):
- `threshold`: 0.80 -> 0.70 generally improves recall.
- `scales`: keep `[1.0]` for constant-size targets; if you truly need scale,
  **list every step** (e.g. 9 steps) -- `_densify_scales` won't interpolate past
  a 1.0 span.
- `rotation_step`: 15 (off = 0).
- `track_enabled/radius/ttl`, `pool_max_ai`: frame-tracking + self-learning.
Save -> ConfigWatcher debounces (500 ms) -> applies live.

## C. Diagnose "no match / hotkey dead"
1. **Bot idles / hotkey no-op**: confirm running **as administrator**; check log
   for `bot running` / `GatherStrategy started`. If missing, strategy not
   instantiated or state stuck -> see lessons #1, #10.
2. **F2 window missing / `Too early to create image`**: tkinter order bug --
   ensure `Tk()` before `PhotoImage` (lesson #2).
3. **Match never hits**: inspect template size (lesson #4) and `window_title`
   (lesson #10). Log should show `matched target | template=... conf=...` once
   working, or `scanning... consecutive misses=N/30` when not.
4. **Click logged but game unaffected**: window not foreground (lesson #10) --
   set real `window_title`, verify `_bring_game_to_foreground` + `_target_still_present`.
5. **Occluded screenshot / vision sees no game**: console overlapping game ->
   move console or fix `window_title` so foreground-bring works.

## D. Verify without the game running
```bash
python autopilot/test_fix.py      config / templates / strategy / state machine
python autopilot/smoke_test.py    fake-screen end-to-end gather chain
python autopilot/dry_run.py       startup self-check (no hotkeys)
python E:\scripts\_verify_ocv.py  4 asserts: CCOEFF/SQDIFF/densify/method
pytest autopilot/tests/          14 template-match cases
```
For UI logic: mock `tkinter`+`PIL`, drive `event_generate` (down->move->up),
assert crop == `frame[top:bottom, left:right]` and right-click returns None.

## E. Rotation augmentation sanity (offline)
- Build an oriented template (e.g. L-shape). Place it at various angles in a
  screen; run full pool match. Expect: original template collapses to ~0.31-0.43
  at large angles, best `rot_*` copy holds ~0.79-0.88 (passes 0.70).
- Confirm `rot_*` count stays constant across re-samples (old copies cleaned
  before regeneration).

## F. Lock / concurrency fixes (if restarting that work)
- `stop()`: under lock only switch state + capture thread ref; `join()` **after**
  releasing the lock. `toggle()` should call start/stop outside the lock.
- `ConfigWatcher._on_config_changed`: parse+validate under lock; dispatch events
  + user callbacks **outside** the lock (copy callback list first).
- Match functions: hold lock only for `get_template`; everything else outside.
