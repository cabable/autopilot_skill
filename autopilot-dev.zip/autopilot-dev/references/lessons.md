# Hard-Won Lessons (read before debugging)

Each item: symptom -> root cause -> fix. file:line are from the pre-skill state;
treat as "where it lives", not exact current line numbers after edits.

## 1. Hotkey does nothing / engine idles
- **Root cause chain** (7 broken links, all fixed): `_load_strategy` set strategy
  to None; state machine stuck in STARTING with no STOP transition; `main.py`
  used default config (config.ini never loaded); 3 config fields failed parsing;
  templates dir resolved relative to CWD (wrong path); F2/F3 were empty TODOs;
  strategy params hardcoded.
- **Fix pattern**: instantiate strategies for real; `start()` triggers START twice
  (STOPPED->STARTING->RUNNING); load config via ConfigWatcher with hot reload;
  `ast.literal_eval` for list/tuple fields; absolute paths from `__file__`;
  implement F2/F3.

## 2. F2 sampling: `Too early to create image: no default root window`
- **Root cause**: `ImageTk.PhotoImage(...)` was called *before* `tk.Tk()`.
  PhotoImage needs an existing Tk root as host.
- **Fix**: build `root = tk.Tk()` (overrideredirect/topmost/geometry) **first**,
  then create the PhotoImage. On PhotoImage failure, `root.destroy()` to avoid a
  stray invisible window.
- **General rule**: in any method creating both a root and a PhotoImage/StringVar,
  root first.

## 3. ImageTk / real-display not needed for logic tests
- Mock `tkinter`+`PIL` and drive events via `event_generate` (down->move->up) to
  assert the returned crop equals `frame[top:bottom, left:right]`. No monitor
  required.

## 4. Match never finds target -- template too large
- A 453x661 sample (61% of 1080p) is unmatchable: `matchTemplate` requires the
  *entire* template (background included) to align; moving the target changes
  surrounding terrain.
- **Rule**: tight bounding box of the target only -- 40-120 px, cap 150 px.

## 5. Planar rotation, NOT scaling
- Confirmed: gather targets are **constant size, varying screen-plane angle**.
  Widening `scales` for them is pure waste (9 steps = ~9x match cost for nothing).
- **Fix**: `scales = [1.0]` + rotation augmentation. F2 generates
  `rot_STEM_ANGLE.png`, rotated **in place** (same size), `BORDER_REPLICATE`
  (NOT black -- black corners read as background to match and drag score down).
  Old templates have no copies -> **re-sample once** after enabling.
- **15 vs 30 degrees**: worst offset 7.5 deg (15) scores about 0.79, above 0.70;
  worst offset 15 deg (30) scores 0.667 below threshold -> silently dropped.
  Use `rotation_step = 15`.

## 6. `_densify_scales` silently drops wide ranges
- If `max-min` exceeds 1.0, it returns config unchanged (no interpolation).
  Listing only endpoints -> only two steps actually used.
- **Fix**: list every intermediate step explicitly when widening.

## 7. Lock discipline -- stop() joins under lock
- `BotEngine.stop()` held `self._lock` while `join()`-ing the engine thread
  (up to 3 s), blocking any other lock acquirer (notably config hot-reload).
  `ConfigWatcher._on_config_changed` also called `bot_engine.update_config`
  (takes bot lock) under its own lock -> opposite lock order, deadlock risk.
- **Fix**: under lock, only switch state + grab thread ref; `join()` *after*
  releasing. Move event dispatch + user callback *outside* `ConfigWatcher._lock`.
  Copy callback list before iterating.

## 8. Unknown BotMode silently idles
- `_load_strategy` else-branch set strategy None -> engine thread runs but does
  nothing, no error.
- **Fix**: raise `ValueError` for unknown mode; `start()` wraps triggers in
  try/except, resets state machine, allows retry (fail-fast).

## 9. coord_query crashes hotkey thread
- `coord_query` did `import mouse` with no ImportError guard and no try/except ->
  ImportError in the global hotkey thread can take down keyboard listening.
- **Fix**: wrap import + read in try/except (match other hotkeys' style).

## 10. Click "succeeds" in logs but game ignores it
- **Chain**: window not foreground -> first click consumed as "activate" -> game
  ignores. Plus `window_title=game.exe` placeholder -> window never identified ->
  bring-to-foreground no-ops; console occludes mss screenshot so vision fallback
  sees no game.
- **Fix**: set real `window_title`; harden `_bring_game_to_foreground`
  (`ShowWindow(SW_RESTORE)` -> `AttachThreadInput` -> `SetForegroundWindow`).
  Replace full-screen diff verification (fooled by cursor/motion) with
  `_target_still_present()` -- if target template still at ROI after click, judge
  fail + warn.

## 11. Only one target ever gathered (others ignored)
- `_scan_for_resources` used `find_best_match` (single top hit). Once that point is
  sticky-blacklisted, every round re-matches it -> skip -> counts as miss; lower-
  confidence targets never get a turn -> max_misses stops the bot.
- **Fix**: `find_multiple_matches` (<=12 NMS candidates), iterate best->worst,
  skip blacklisted, first un-blacklisted becomes target.

## 12. AI knowledge never fed back to OpenCV
- `_load_reference_templates()` passed `ai_*` templates only to the vision model
  as reference images, not into OpenCV matching. Every round re-missed 8-15x then
  asked AI.
- **Fix**: `_template_pool()` merges active + `rot_*` + recent `ai_*` into the
  OpenCV match set -> "AI teaches once -> OpenCV finds next time -> AI calls drop".

## 13. mss / numpy coords -- no DPI scaling
- Both `grab()` and `grab_roi()` return physical pixels; numpy slice indices are
  the same space. Never apply DPI multipliers. Keep "boxed = saved from same
  frame" (slice `frame[top:bottom, left:right]`, don't re-`grab_roi`).

## 14. Editing .py needs a restart
- Config hot-reload only applies `config.ini`. Any `.py` change requires
  restarting the AutoPilot process.

## 15. Performance wins already landed (don't re-do)
- Gray converted once per frame + gray template cache (not per-scale).
- `find_best_match` early-exit at >=0.95.
- `grab()` merges black-frame + hash into one cvtColor; hash lazy (only on
  `has_changed()`).
- Image pyramid coarse-to-fine (k=1 lock; k=2 drops recall 1.0->0.88).
- `find_multiple_matches` uses `cv2.dilate` local maxima instead of `np.where`.
- Engine loop `stop_event.wait(0.01)` instead of `time.sleep(0.01)`.
- Match functions hold lock only for `get_template` ref; cvtColor/pyrDown/
  matchTemplate run outside the lock.
- **Pitfall during T3-3**: inner `with self._lock:` left unclosed -> `return`
  fell inside the `for scale` loop -> only first scale matched. Keep the lock
  closed immediately after fetching the template ref.
