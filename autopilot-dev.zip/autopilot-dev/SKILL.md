---
name: autopilot-dev
description: |-
  Development, debugging, and tuning knowledge for the AutoPilot game-automation
  bot at E:\scripts\autopilot (Python + OpenCV template matching + tkinter
  sampling UI + AI vision fallback). Use when modifying autopilot code, fixing
  "hotkey does nothing / match cannot find target / sampling broken" issues,
  tuning template-matching parameters in config.ini, or extending the
  gather/combat/fishing strategies. Encodes project-specific hard-won lessons
  (tkinter PhotoImage ordering, mss coordinate system, _densify_scales behavior,
  template sizing rules, planar-rotation augmentation, lock discipline, config
  hot-reload vs code-restart boundary, window-identification and click-landing
  fix).
agent_created: true
---

# AutoPilot Dev Skill

Expert knowledge for building, debugging, and tuning the **AutoPilot** game
automation bot (Windows, Python). Project root: `E:\scripts\autopilot`. Entry
points: `autopilot/main.py` (CLI) and `run_gui.py` (GUI). Source docs this skill
is distilled from live in `E:\scripts\docs\`.

## When to use

- Modifying `autopilot/` source (strategies, template store, screen grabber,
  vision client, bot engine, hotkeys).
- Any of: hotkey does nothing; F2 sampling fails or window does not appear;
  template match never finds the target; config.ini changes seem ignored;
  bot starts but does nothing; click "registers" in logs but game does not react.
- Tuning `config.ini` (`[DEFAULT]`, `[strategy.gather]`) for match quality.
- Adding a new gather/combat/fishing capability.

## Project snapshot

- **Layered architecture**: `application/` (strategies + bot_engine) ->
  `core/` (state machine, event bus) -> `domain/` (models, enums) ->
  `infrastructure/` (template_store, screen_grabber, vision_client,
  config_watcher, input_simulator) -> `presentation/`. Dependencies point inward.
- **Modes**: F5 gather, F6 combat, F7 fishing, F8 stop, F9 coord-query,
  F10 exit, F2 sample-template, F3 screenshot-preview, F4 vision-analyze,
  F11 ai-train.
- **Match pipeline** (per scan tick): `grab()` full screen ->
  `_windowed_view()` numpy slice to game window ->
  `TemplateStore.find_multiple_matches(crop, template_id, scales, threshold)`.
- **Self-learning loop**: AI vision fallback (`VisionTargetChannel`) pushes
  manual/auto hits back into the running gather loop; AI-saved `ai_*` templates
  are merged into the OpenCV match pool (`_template_pool`).
- **Run as administrator** (simulated input requires it). Always **restart the
  process** after editing `.py` -- hot-reload only applies `config.ini`.

## Critical rules (read before editing)

1. **tkinter ordering**: create `tk.Tk()` *before* `ImageTk.PhotoImage(...)`.
   The reverse throws `Too early to create image: no default root window`.
   Applies whenever a UI method builds both a root and a PhotoImage in one place
   (e.g. `_region_select`).
2. **mss coordinate system**: screen_grabber returns physical pixels; numpy
   slicing and `grab_roi` use the same space -- do **not** apply DPI scaling.
   Crop a region with pure array indexing, never re-grab via `grab_roi` after a
   region-select (keep "what you boxed is what you saved").
3. **`_densify_scales` gotcha**: if `max(scales) - min(scales)` exceeds 1.0, it
   returns the config **unchanged** (no interpolation). To widen search range
   you MUST list every intermediate step explicitly (e.g. 9 steps), not just
   endpoints. With `len(scales)` below 2 it returns as-is (safe single-step).
4. **Template sizing**: samples must be a tight bounding box of the target
   **only** -- ideal 40-120 px, hard cap 150 px. A 453x661 template (61% of a
   1080p screen) is effectively unmatchable because matchTemplate requires the
   *entire* template region (background included) to align.
5. **Planar rotation, not scaling**: gather targets are **constant size,
   varying screen-plane angle**. Do NOT widen `scales` for them -- keep
   `scales = [1.0]`; use **rotation augmentation** (`rotation_step = 15`):
   F2 generates `rot_STEM_ANGLE.png` copies, rotated **in place** (same output
   size, `BORDER_REPLICATE` fill -- NOT black, which reads as background to
   match). 15-degree worst-case 7.5 deg offset scores about 0.79, above 0.70;
   30-degree step worst-case 0.667 below threshold -> silently dropped. Use 15.
6. **Lock discipline**: never `join()` the engine thread while holding
   `bot_engine._lock` (causes long lock-hold / potential deadlock with
   ConfigWatcher's reload callback). Release the lock, then join. Hot-reload
   callback must not do heavy work under `ConfigWatcher._lock`.
7. **Window identification**: set `[window] window_title` to the **real** game
   window title (not the `game.exe` placeholder) or foreground-bringing fails,
   clicks land on the wrong window, and mss screenshots get occluded by the
   console. `config.ini` changes here hot-reload; verify via log
   (`foreground window=...`, `WARNING: game window not identified`).
8. **Click-not-landing root cause chain**: game window not foreground -> first
   click is consumed as "activate" -> game ignores it. Fix = correct
   `window_title` + hardened `_bring_game_to_foreground`
   (`ShowWindow(SW_RESTORE)` -> `AttachThreadInput` -> `SetForegroundWindow`).
   Verify with `_target_still_present()` (target still at ROI after click =>
   fail + warn) rather than full-screen diff (easily fooled by cursor/motion).

## Common workflows

- **Sample a template (F2)**: box-select on the frozen full-screen snapshot ->
  crop sliced from that same frame. After F2, **rotation copies are generated
  automatically**; old templates have none, so **re-sample once** after enabling
  rotation.
- **Tune matching**: edit `[strategy.gather]` (not `[DEFAULT]`) --
  `threshold` (0.80 -> 0.70 typical), `scales` (list all needed steps),
  `rotation_step`, `track_enabled/radius/ttl`, `pool_max_ai`. Changes hot-reload.
- **Diagnose "no match"**: check log for `matched target | template=... conf=...`
  vs `scanning... consecutive misses=N/30`. Screenshot-occlusion or wrong
  template size are the usual culprits.
- **Verify without launching the game**: `python autopilot/test_fix.py`,
  `python autopilot/smoke_test.py`, `python autopilot/dry_run.py`. Regression for
  match logic: `E:\scripts\_verify_ocv.py` (4 asserts) and
  `tests/test_template_match.py` (14 cases).

## References

- `references/architecture.md` -- module map, match pipeline detail, config
  schema, self-learning and frame-tracking design.
- `references/lessons.md` -- the full hard-won pitfall catalog with file:line and
  fix summaries (highest-value file; read before debugging).
- `references/workflows.md` -- step-by-step recipes: sampling, tuning,
  diagnosing click-lands-but-game-ignores, rotation augmentation, lock fixes.
- `references/roadmap.md` -- known issues / open items from the code review
  (config regex-replace fragility, gather_strategy 877-line refactor, async
  EventBus dead code, etc.) and the full-automation gap analysis.
